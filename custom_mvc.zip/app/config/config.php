<?php

//DATABASE RELATED Details
define('DB_HOST', 'localhost');
define('DB_NAME', 'php-custom-mvc');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
//site address
define('HOME', 'http://' . $_SERVER['HTTP_HOST'] . '/custom_mvc/public/');
//set prefix for sessions
define('SESSION_PREFIX','php-custom-mvc');
